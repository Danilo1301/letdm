export interface ProcessPricesTableOptions {
    description: string;
    code: string;
    price: string;
    minPriceChange: number
}